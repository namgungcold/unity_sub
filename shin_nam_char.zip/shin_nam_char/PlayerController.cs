using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent (typeof (CunController))]
public class PlayerController : LivingEntity{   
    [SerializeField]
    private float walkSpeed;

    [SerializeField]
    private Rigidbody myRigid;

    [SerializeField]
    private float jumpForce;

    private bool isGround = true;
    

    CunController gunController;
    private FPS_Camera rotateToMouse; // 마우스 이동으로 카메라 회전
    private Zoom zoom;

    [SerializeField]
    private CapsuleCollider capsuleCollider; 
    
    protected override void Start(){
    {
        base.Start();
        rotateToMouse = GetComponent<FPS_Camera>();
        zoom = GetComponentInChildren<Zoom>();
        gunController = GetComponent<CunController>();
        myRigid = GetComponent<Rigidbody>();
        capsuleCollider = GetComponent<CapsuleCollider>();
    }
    }
 
    void Update()
    {
        UpdateRotate();
        UpdateZoom();
        Move();
        IsGround();
        TryJump();
        if (Input.GetMouseButton(0))
        {
            gunController.Shoot();
        }

    }
 
    void UpdateRotate()
    {
        float mouseX = Input.GetAxis("Mouse X");
        float mouseY = Input.GetAxis("Mouse Y");
        rotateToMouse.CalculateRotation(mouseX, mouseY);
    }
 
    void UpdateZoom()
    {
        float t_zoomDirection = Input.GetAxis("Mouse ScrollWheel");
        zoom.ZoomInOut(t_zoomDirection);
    }
    void Move(){
        float _moveDirX = Input.GetAxisRaw("Horizontal");  
        float _moveDirZ = Input.GetAxisRaw("Vertical"); 
        Vector3 _moveHorizontal = transform.right * _moveDirX; 
        Vector3 _moveVertical = transform.forward * _moveDirZ; 

        Vector3 _velocity = (_moveHorizontal + _moveVertical).normalized * walkSpeed;
         myRigid.MovePosition(transform.position + _velocity * Time.deltaTime);
    }
    private void IsGround()
    {
        isGround = Physics.Raycast(transform.position, Vector3.down, capsuleCollider.bounds.extents.y + 0.1f);
    }


    private void TryJump()
    {
        if (Input.GetKeyDown(KeyCode.Space) && isGround)
        {
            Jump();
        }
    }
    private void Jump()
    {
        myRigid.velocity = transform.up * jumpForce;
    }
}

